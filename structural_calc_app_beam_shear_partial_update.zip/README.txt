Structural Calculation App

Current modules in this build:
- Gravity / Beam Analysis
- Gravity / Beam Design
- Wind

This build reflects the merged-and-cleaned app direction rather than an older beam-only review build.

Current structure notes:
- Beam Analysis and Beam Design live under the Gravity module.
- Wind includes the main setup sheet, pressure sheet, tributary diaphragm sheet (4.2), and Kzt sheet.
- 4.2 uses an off-sheet control rail and printable directional sheets.

Reserved future slots remain visible in the tree for later module growth, but they are not active modules yet.
